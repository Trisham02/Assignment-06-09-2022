﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumArray.cs
{
    public class Program
    {
        public static void Main()
        {
            int[] a = new int[100];
            int i, n, sum = 0;


            Console.WriteLine("\n\nFind sum of all elements of array:\n");
            Console.WriteLine("--------------------------------------\n");

            Console.WriteLine("Input the number of elements to be stored in the array :");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Input {0} elements in the array :\n", n);
            for (i = 0; i < n; i++)
            {
                Console.WriteLine("element - {0} : ", i);
                a[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (i = 0; i < n; i++)
            {
                sum += a[i];
            }

            Console.WriteLine("Sum of all elements stored in the array is : {0}\n\n", sum);
        }
    }
}